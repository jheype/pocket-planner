export function requireAppToken() {
  return null;
}

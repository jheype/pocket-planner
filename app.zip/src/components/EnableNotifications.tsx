"use client";

import { useEffect, useState } from "react";
import { authedFetch } from "@/lib/authedFetch";

type Status = "idle" | "working" | "enabled" | "error";

type OneSignalPushSubscription = {
  id?: string;
  optedIn?: boolean;
};

type OneSignalUser = {
  PushSubscription?: OneSignalPushSubscription;
};

type OneSignalSlidedown = {
  promptPush: () => Promise<void>;
};

type OneSignalLike = {
  init: (opts: { appId: string; allowLocalhostAsSecureOrigin?: boolean }) => Promise<void> | void;
  Slidedown: OneSignalSlidedown;
  User?: OneSignalUser;
};

declare global {
  interface Window {
    OneSignalDeferred?: Array<(os: OneSignalLike) => void | Promise<void>>;
  }
}

function sleep(ms: number) {
  return new Promise<void>((r) => setTimeout(r, ms));
}

function getSubId(os: OneSignalLike): string | null {
  const id = os.User?.PushSubscription?.id;
  return typeof id === "string" && id.trim() ? id : null;
}

function isOptedIn(os: OneSignalLike): boolean {
  return Boolean(os.User?.PushSubscription?.optedIn);
}

async function waitForSubscription(os: OneSignalLike) {
  for (let i = 0; i < 20; i++) {
    const optedIn = isOptedIn(os);
    const id = getSubId(os);
    if (optedIn && id) return { optedIn, id };
    await sleep(250);
  }
  return { optedIn: isOptedIn(os), id: getSubId(os) };
}

export default function EnableNotifications() {
  const [status, setStatus] = useState<Status>("idle");

  useEffect(() => {
    let alive = true;

    window.OneSignalDeferred = window.OneSignalDeferred || [];
    window.OneSignalDeferred.push(async (OneSignal) => {
      try {
        await OneSignal.init({
          appId: process.env.NEXT_PUBLIC_ONESIGNAL_APP_ID!,
          allowLocalhostAsSecureOrigin: true,
        });

        const { optedIn, id } = await waitForSubscription(OneSignal);
        if (alive && optedIn && id) setStatus("enabled");
      } catch {
        if (alive) setStatus("error");
      }
    });

    return () => {
      alive = false;
    };
  }, []);

  async function enable() {
    setStatus("working");

    window.OneSignalDeferred = window.OneSignalDeferred || [];
    window.OneSignalDeferred.push(async (OneSignal) => {
      try {
        await OneSignal.init({
          appId: process.env.NEXT_PUBLIC_ONESIGNAL_APP_ID!,
          allowLocalhostAsSecureOrigin: true,
        });

        await OneSignal.Slidedown.promptPush();

        const { optedIn, id } = await waitForSubscription(OneSignal);

        if (!optedIn || !id) {
          setStatus("error");
          return;
        }

        const res = await authedFetch("/api/device", {
          method: "POST",
          body: JSON.stringify({
            playerId: id,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          }),
        });

        if (!res.ok) {
          setStatus("error");
          return;
        }

        setStatus("enabled");
      } catch {
        setStatus("error");
      }
    });
  }

  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-sm font-semibold">Notifications</div>
      <div className="mt-1 text-xs text-white/60">
        Install the app to your Home Screen, then enable notifications.
      </div>

      <button
        onClick={enable}
        disabled={status === "working" || status === "enabled"}
        className="mt-3 w-full rounded-xl bg-white/10 px-3 py-2 text-sm disabled:opacity-50"
      >
        {status === "enabled" ? "Enabled" : status === "working" ? "Enabling…" : "Turn on"}
      </button>

      {status === "error" && (
        <div className="mt-2 text-xs text-red-300">
          Couldn&apos;t enable notifications. Check your app token and open from Home Screen.
        </div>
      )}
    </div>
  );
}
